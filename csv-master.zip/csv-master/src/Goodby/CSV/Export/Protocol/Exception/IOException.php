<?php

namespace Goodby\CSV\Export\Protocol\Exception;

/**
 * Throws if it is unable to write CSV file
 */
class IOException extends \RuntimeException
{
}
