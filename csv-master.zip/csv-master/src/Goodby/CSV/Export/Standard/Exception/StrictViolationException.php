<?php

namespace Goodby\CSV\Export\Standard\Exception;

class StrictViolationException extends \RuntimeException
{
}
