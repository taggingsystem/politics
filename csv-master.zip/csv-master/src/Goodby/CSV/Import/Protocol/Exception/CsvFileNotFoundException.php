<?php

namespace Goodby\CSV\Import\Protocol\Exception;

/**
 * Throws if csv file not found
 */
class CsvFileNotFoundException extends \RuntimeException
{
}
